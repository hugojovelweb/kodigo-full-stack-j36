<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('order_number')->unique();
            $table->decimal('total', 10, 2)->default(0);
            $table->enum('status', [
                'pending',    // creada, esperando pago
                'paid',       // pago confirmado por Stripe
                'processing', // en preparación
                'shipped',    // enviada
                'completed',  // finalizada
                'cancelled',  // cancelada
                'failed',     // pago fallido
            ])->default('pending');
            $table->text('shipping_address')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
